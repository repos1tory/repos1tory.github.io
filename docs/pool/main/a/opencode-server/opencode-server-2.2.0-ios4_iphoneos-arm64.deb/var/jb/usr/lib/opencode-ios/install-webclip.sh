#!/var/jb/bin/sh
set -eu

clip_id="E4EAA6B3A2214E94B70D4C0244F6E126"
clip_root="/var/mobile/Library/WebClips"
clip_dir="$clip_root/$clip_id.webclip"
icon_source="/var/jb/usr/lib/opencode-ios/webclip-icon.png"
settings="/var/mobile/.config/opencode-ios/settings.conf"
port=4096

if [ -r "$settings" ]; then
  while IFS='=' read -r key value; do
    [ "$key" = "PORT" ] && port="$value"
  done < "$settings"
fi
case "$port" in ''|*[!0-9]*) port=4096 ;; esac
if [ "$port" -lt 1024 ] || [ "$port" -gt 65535 ]; then port=4096; fi

if [ ! -f "$icon_source" ]; then
  echo "Missing OpenCode PWA icon: $icon_source" >&2
  exit 1
fi

mkdir -p "$clip_dir"
cat > "$clip_dir/Info.plist.new" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>ApplicationBundleVersion</key>
  <integer>1</integer>
  <key>ClassicMode</key>
  <false/>
  <key>ConfigurationIsManaged</key>
  <false/>
  <key>ContentMode</key>
  <string>UIWebClipContentModeRecommended</string>
  <key>Eligibility</key>
  <integer>0</integer>
  <key>FullScreen</key>
  <true/>
  <key>IconIsPrecomposed</key>
  <true/>
  <key>IconIsScreenShotBased</key>
  <false/>
  <key>IgnoreManifestScope</key>
  <false/>
  <key>IsAppClip</key>
  <false/>
  <key>Orientations</key>
  <integer>0</integer>
  <key>PlaceholderBundleIdentifier</key>
  <string>com.apple.WebKit.PushBundle.$clip_id</string>
  <key>ScenelessBackgroundLaunch</key>
  <false/>
  <key>Title</key>
  <string>OpenCode PWA</string>
  <key>URL</key>
  <string>http://127.0.0.1:$port/</string>
  <key>WebClipStatusBarStyle</key>
  <string>UIWebClipStatusBarStyleLegacyBlackTranslucent</string>
</dict>
</plist>
EOF
cp "$icon_source" "$clip_dir/icon.png.new"
chown mobile:mobile "$clip_dir" "$clip_dir/Info.plist.new" "$clip_dir/icon.png.new"
chmod 755 "$clip_dir"
chmod 644 "$clip_dir/Info.plist.new" "$clip_dir/icon.png.new"
mv "$clip_dir/Info.plist.new" "$clip_dir/Info.plist"
mv "$clip_dir/icon.png.new" "$clip_dir/icon.png"

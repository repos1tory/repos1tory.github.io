#!/var/jb/bin/sh
set -e

server_port=4097
legacy_db="/var/mobile/.local/share/opencode/opencode-ios-port.db"
migration_root="/var/jb/var/mobile/.local/share/opencode-ios-migration"
pending="$migration_root/pending"
helper="/var/jb/usr/lib/opencode-ios/merge-sessions.mjs"
node="/var/jb/usr/lib/opencode-ios/node"

[ -f "$pending/manifest.json" ] || exit 0

attempt=0
while [ "$attempt" -lt 120 ]; do
  if /var/jb/usr/bin/curl -fsS --connect-timeout 1 --max-time 2 \
    "http://127.0.0.1:$server_port/api/info" >/dev/null 2>&1; then
    break
  fi
  /var/jb/usr/bin/sleep 1
  attempt=$((attempt + 1))
done
if [ "$attempt" -ge 120 ]; then
  echo "OpenCode Server did not start for session import; the export and source DB were retained." >&2
  exit 1
fi

if ! "$node" --predictable --single-threaded --disable-wasm-trap-handler \
  "$helper" import "http://127.0.0.1:$server_port" "$pending"; then
  echo "Session import failed; the export and source DB were retained for retry." >&2
  exit 1
fi

if [ -f "$legacy_db" ] || [ -f "$legacy_db-wal" ] || [ -f "$legacy_db-shm" ] || [ -f "$legacy_db-journal" ]; then
  archive="$migration_root/archive/legacy-$(date +%Y%m%d%H%M%S)-$$"
  mkdir -p "$archive"
  chown -R mobile:mobile "$archive"
  chmod 700 "$archive"
  for suffix in "" -wal -shm -journal; do
    if [ -f "$legacy_db$suffix" ]; then
      /var/jb/usr/bin/mv "$legacy_db$suffix" "$archive/opencode-ios-port.db$suffix"
    fi
  done
fi

/var/jb/usr/bin/rm -rf "$pending"
